package com.ly.bean;

/**
 * Created by ly on 2024/9/5
 */
public class User {

    private String username;

    private String pws;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPws() {
        return pws;
    }

    public void setPws(String pws) {
        this.pws = pws;
    }

}
