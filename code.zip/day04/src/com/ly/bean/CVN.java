package com.ly.bean;

/**
 * Created by ly on 2024/9/5
 */
public class CVN {

    private String name;

    public String length;

    public String width;

    public String fighter;

    public String getName() {
        return name;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getFighter() {
        return fighter;
    }

    public void setFighter(String fighter) {
        this.fighter = fighter;
    }

    public void setName(String name) {
    }

}
