package com.ly.bean;

/**
 * Created by ly on 2024/9/5
 */
public class Fighter {

    private String name;

    public String color;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }



}
